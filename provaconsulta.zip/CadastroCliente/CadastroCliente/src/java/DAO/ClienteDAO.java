/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Cliente;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;

/**
 *
 * @author aluno
 */
public class ClienteDAO implements IDAO{

    @Override
    public void cadastrar(Object o) {
        Cliente c = (Cliente) o;
        EntityManagerFactory emf = FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(c);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public void alterar(Object o) {
        Cliente c = (Cliente) o;
         EntityManagerFactory emf= FabricaConexao.getConexao();        
        EntityManager em = emf.createEntityManager();
        Cliente cAux = em.find(Cliente.class, c.getId());
        if(cAux==null){
            try {            
                throw new Exception("Cliente nao existe mais!");
            } catch (Exception ex) {
                Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        em.getTransaction().begin();
        em.merge(c);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public void excluir(Object o) {
        Cliente c = (Cliente) o;
        EntityManagerFactory emf= FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        c = em.find(Cliente.class, c.getId());
        em.remove(c);
        em.getTransaction().commit();
        em.close();        
    }

    @Override
    public List listar() {
        EntityManagerFactory emf= FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        TypedQuery<Cliente> query = em.createQuery("SELECT c FROM Cliente c",Cliente.class);
        List<Cliente> lista = query.getResultList();
        //for(Cliente cl:lista){
         //   System.out.println(cl);
        //}
        em.close();
        emf.close();
        return lista;
    }
    
      public List consultar() {
        
        EntityManagerFactory emf = FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
         TypedQuery<Cliente> query = em.createQuery("Select d  From Cliente d", Cliente.class);
         List <Cliente> lista = query.getResultList();
         em.close();
         return lista;  
     
    }
         public Object listarId(long i)  {
    EntityManagerFactory emf= FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        TypedQuery<Cliente> query = em.createQuery("SELECT c FROM Cliente c where c.id=" +i,Cliente.class);
        Cliente c = query.getSingleResult();
        em.close();
       return c; }   
    
}
