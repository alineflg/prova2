
package DAO;

import java.util.List;

public interface IDAO {
    public void cadastrar(Object o);
    public void alterar(Object o);
    public void excluir(Object o);
    public List listar();
    
}
