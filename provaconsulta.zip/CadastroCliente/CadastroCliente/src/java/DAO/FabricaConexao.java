package DAO;


import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class FabricaConexao {
    
    public static EntityManagerFactory getConexao(){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("CadastroClientePU");
        return emf;
    }
}
