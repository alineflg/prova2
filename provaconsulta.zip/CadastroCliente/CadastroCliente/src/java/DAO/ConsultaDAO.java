/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Consulta;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;

/**
 *
 * @author aluno
 */
public class ConsultaDAO implements IDAO{

    @Override
    public void cadastrar(Object o) {
        Consulta c = (Consulta) o;
        EntityManagerFactory emf = FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(c);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public void alterar(Object o) {
        Consulta c = (Consulta) o;
         EntityManagerFactory emf= FabricaConexao.getConexao();        
        EntityManager em = emf.createEntityManager();
        Consulta cAux = em.find(Consulta.class, c.getId());
        if(cAux==null){
            try {            
                throw new Exception("Consulta nao existe mais!");
            } catch (Exception ex) {
                Logger.getLogger(ConsultaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        em.getTransaction().begin();
        em.merge(c);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public void excluir(Object o) {
        Consulta c = (Consulta) o;
        EntityManagerFactory emf= FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        c = em.find(Consulta.class, c.getId());
        em.remove(c);
        em.getTransaction().commit();
        em.close();        
    }

    @Override
    public List listar() {
        EntityManagerFactory emf= FabricaConexao.getConexao();
        EntityManager em = emf.createEntityManager();
        TypedQuery<Consulta> query = em.createQuery("SELECT c FROM Consulta c",Consulta.class);
        List<Consulta> lista = query.getResultList();
        //for(Consulta cl:lista){
         //   System.out.println(cl);
        //}
        em.close();
        emf.close();
        return lista;
    }
    
}
