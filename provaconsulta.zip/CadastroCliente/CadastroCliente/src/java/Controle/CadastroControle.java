package Controle;

import DAO.ClienteDAO;
import Model.Cliente;
import java.sql.SQLException;
import java.util.List;

public class CadastroControle {
    private ClienteDAO dao;
    
   
    public CadastroControle(){
        this.dao= new ClienteDAO();
    }
    public void cadastrar(Cliente c){
        if(this.dao == null){
            this.dao= new ClienteDAO();
        }
        this.dao.cadastrar(c);     
    } 
    public List ListarCliente(){ 
          if(this.dao == null){
            this.dao= new ClienteDAO();
          }
        return this.dao.listar();
     }
    public void ExcluirCliente(Cliente c){
        if(this.dao == null){
            this.dao= new ClienteDAO();
        }
        this.dao.excluir(c);   
    }
     public void AtualizarCliente(Cliente c){
        if(this.dao == null){
            this.dao= new ClienteDAO();
        }
        this.dao.alterar(c);      
    }

    public Object consultarId(int i)throws SQLException{
    if (this.dao==null){
       this.dao = new ClienteDAO();
      }  
       
        return this.dao.listarId(i);
        } 
}
