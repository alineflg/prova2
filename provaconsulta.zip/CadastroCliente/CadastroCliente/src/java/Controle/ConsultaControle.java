package Controle;

import DAO.ConsultaDAO;
import Model.Consulta;
import Model.Consulta;
import java.sql.SQLException;
import java.util.List;

public class ConsultaControle {
    private ConsultaDAO dao;
    
   
    public ConsultaControle(){
        this.dao= new ConsultaDAO();
    }
    public void cadastrar(Consulta c){
        if(this.dao == null){
            this.dao= new ConsultaDAO();
        }
        this.dao.cadastrar(c);     
    } 
    public List ListarConsulta(){ 
          if(this.dao == null){
            this.dao= new ConsultaDAO();
          }
        return this.dao.listar();
     }
    public void ExcluirConsulta(Consulta c){
        if(this.dao == null){
            this.dao= new ConsultaDAO();
        }
        this.dao.excluir(c);   
    }
     public void AtualizarConsulta(Consulta c){
        if(this.dao == null){
            this.dao= new ConsultaDAO();
        }
        this.dao.alterar(c);      
    }
 
  /*  public Consulta consultarID(Long id)  {
        if (this.dao==null){
       this.dao = new ConsultaDAO();
      }  
        return (Consulta) this.dao.listarId(id);
    }
*/
  
}